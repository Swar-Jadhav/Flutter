import 'package:flutter/material.dart';

const Color textPrimary= Color(0xff313745);
const Color dayPrimary=Color(0xffe5ecf4);