import 'package:flutter/material.dart';
import '../Constants.dart' as Constants;





class textfield extends StatelessWidget {
  final String text;
  final bool isPassword;

  const textfield({
    super.key,
    required this.text, required this.isPassword,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: EdgeInsets.all(16.1),
    child: TextField(
      style: TextStyle(
        color: Constants.dayPrimary
      ),
    obscureText: isPassword,
      decoration: InputDecoration(
          hintText: text,
          hintStyle: TextStyle(
              color: Constants.dayPrimary,
              fontWeight: FontWeight.w700,
              fontStyle: FontStyle.italic,
              fontSize: 20.0

          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              color: Constants.dayPrimary,
              width: 1.3,
              style: BorderStyle.solid,
            ),
          )
      ),
    ),
    );
  }
}